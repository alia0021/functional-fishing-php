<?php

/**
 * Referenced Blacksmith and received help from TA ANTONE
 */
session_start();
/**
 * createGameData
 * Creates a new session data
 * 
 * @return bool
 */
function createGameData()
{
  $_SESSION['functional_fishing'] = [
    'response' => [],
    'fish' => 0,
    'wood' => 0,
    'bait' => 0,
    'fire' => false
  ];

  return isset($_SESSION['functional_fishing']);
}

/**
 * getResponse
 * Gets the response history array from the session and converts to a string
 * 
 * This function should be used to get the full response array as a string
 * 
 * @return string
 */
function getResponse()
{
  return implode('<br><br>', $_SESSION['functional_fishing']['response']);
}

/**
 * updateResponse
 * Adds a new response to the response array found in session
 * Returns the full response array as a string
 * 
 * This function should be used each time an action returns a response
 * 
 * @param [string] $response
 * @return string
 */
function updateResponse($response)
{
  if (!isset($_SESSION['functional_fishing'])) {
    createGameData();
  }
  array_push($_SESSION['functional_fishing']['response'], $response);

  return getResponse();
}
/**
 * wood function to add wood
 * 
 */

function wood()
{
  if ($_SESSION['functional_fishing']['fire']) {
    return "You need turn off the fire";
  } else {
    $_SESSION['functional_fishing']["wood"]++;
    return "You got wood";
  }
}
/**
 * bait function 
 * 
 */

function bait()
{
  if ($_SESSION['functional_fishing']['fire']) {
    return "You need to turn off your fire.";
  } else {
    $_SESSION['functional_fishing']['bait']++;
    return "You got bait";
  }
}
/**
 * fish function 
 * 
 */
function fish()
{
  if ($_SESSION['functional_fishing']['fire']) {
    return "fire needs to be turned off";
  } else {
    if ($_SESSION['functional_fishing']['bait'] > 0) {
      $var = rand(0, 1);
      if ($var < 1) {
        $_SESSION['functional_fishing']['fish']++;
        return "You got fish";
      } else {
        return "Sorry, you aren't lucky";
      }
    } else {
      return "You need bait";
    }
  }
}


/**
 * fire
 * Used to start/stop the fire
 * Updates the Session data
 * 
 * @return string
 */
function fire()
{
  if ($_SESSION['functional_fishing']['fire']) {
    $_SESSION['functional_fishing']["fire"] = false;
    return "You have put out the fire";
  } else {
    if ($_SESSION['functional_fishing']['wood'] > 0) {
      $_SESSION['functional_fishing']["wood"]--;
      $_SESSION['functional_fishing']["fire"] = true;
      return "You have started a fire";
    } else {
      return "You do not have enough wood";
    }
  }
}

/**
 * inventory
 * Used to return session data (formatted)
 * 
 * @return string
 */
function inventory()
{
  $responses = '';

  foreach ($_SESSION['functional_fishing'] as $item => $value) {
    if ($item === 'fire') {
      if ($value) {
        $responses .= "The fire is going";
      } else {
        $responses .= "The fire is out";
      }
    } else if (!is_array($value)) {
      $responses .= "{$value} ${item}<br>";
    }
  }

  return $responses;
}

/**
 * eat function 
 * 
 */
function eat()
{
  if (!$_SESSION['functional_fishing']['fire']) {
    return "fire needs to be turned on";
  } else {
    if ($_SESSION['functional_fishing']['fish'] > 0) {
      $_SESSION['functional_fishing']['eat']++;
      return "You have eaten";
    } else {
      return "You need 1 fish to eat.";
    }
  }

}

/**
 * restart
 * Used to clear session data and start over
 * Updates the session data
 *  
 * @return string
 */
function restart()
{
  createGameData();

  return 'The game has restarted';
}
/**
 * help
 * Returns a formatted string of game instructions
 * 
 * @return string
 */
function help()
{
  return 'Welcome to Functional Fishing, the text based fishing game. Use the following commands to play the game: <span class="red">eat</span>, <span class="red">fish</span>, <span class="red">fire</span>, <span class="red">wood</span>, <span class="red">bait</span>. To restart the game use the <span class="red">restart</span> command For these instruction again use the <span class="red">help</span> command';
}

/**
 * Create a response based on the players commands
 * - If the player has entered a command 
 *    - extract the command from the player's input
 *      - the explode function will split the input on the space separate the 
 *        command from the option
 *    - check if the entered command is a valid function using function_exists
 *      - check for a command option
 *        - execute command with option using the variable function technique
 *        - updateResponse with function's results
 *      - else
 *        - execute command using the variable function technique
 *        - updateResponse with function's results
 *    - else
 *      - updateResponse with invalid command  
 */
if (isset($_POST['command'])) {
  $command = explode(' ', strtolower($_POST['command']));
  if (function_exists($command[0])) {
    if (isset($command[1])) {
      updateResponse($command[0]($command[1]));
    } else {
      updateResponse($command[0]());
    }
  } else {
    updateResponse("{$_POST['command']} is not a valid command");
  }
}
